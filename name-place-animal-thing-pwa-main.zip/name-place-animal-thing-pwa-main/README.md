# Name, Place, Animal, Thing PWA

A Progressive Web App for playing the classic word game.

## License

This project is licensed under the [MIT License](LICENSE) - see the [LICENSE](LICENSE) file for details.
